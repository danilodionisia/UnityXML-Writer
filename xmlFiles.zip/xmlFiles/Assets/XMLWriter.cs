﻿//XMLWriter
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//adicione os usings
using System.Xml;
using System.IO;
using UnityEngine.UI;


public class XMLWriter : MonoBehaviour {
    //cria as variáveis para receber os inputfields
    public InputField IFLogin, IFPassword, IFPoints;

    void Start () {
		
	}
		
	void Update () {    }

    public void WriteToXml()
    {
        //passa o caminho do arquivo
        string filepath = Application.dataPath 
            + @"/gamexmldata.xml";
        
        //instancia a classe XmlDocument
        XmlDocument xmlDoc = new XmlDocument();

        if (IFLogin.text != string.Empty && IFPassword.text != string.Empty)
        {

            //verifica se o arquivo existe
            if (File.Exists(filepath))
            {
                //carrega o arquivo
                xmlDoc.Load(filepath);

                //carrega os elementos
                XmlElement elmRoot = xmlDoc.DocumentElement;

                //cria as tags para separar as informações
                XmlElement elmNew = xmlDoc.CreateElement("data");

                XmlElement login = xmlDoc.CreateElement("login");
                XmlElement password = xmlDoc.CreateElement("password");
                XmlElement points = xmlDoc.CreateElement("points");

                //pega o texto da caixa de texto e passa para a tag
                login.InnerText = IFLogin.text;
                password.InnerText = IFPassword.text;
                points.InnerText = IFPoints.text;

                //limpa as caixas de texto
                IFLogin.text = string.Empty;
                IFPassword.text = string.Empty;
                IFPoints.text = string.Empty;

                //salva no final do documento xml
                elmNew.AppendChild(login);
                elmNew.AppendChild(password);
                elmNew.AppendChild(points);

                elmRoot.AppendChild(elmNew);
                //salva o documento todo
                xmlDoc.Save(filepath);
            }
        }
    }
}
