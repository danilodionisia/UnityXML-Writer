﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using System.Xml;
using System.IO;
using UnityEngine.UI;


public class XMLWriter : MonoBehaviour {

    public InputField IFLogin, IFPassword, IFPoints;

    void Start () {
		
	}
	
	
	void Update () {
		
	}

    public void WriteToXml()
    {

        string filepath = Application.dataPath + @"/gamexmldata.xml";
        XmlDocument xmlDoc = new XmlDocument();

        if (File.Exists(filepath))
        {
            xmlDoc.Load(filepath);

            XmlElement elmRoot = xmlDoc.DocumentElement;

            XmlElement elmNew = xmlDoc.CreateElement("data"); 
            XmlElement login = xmlDoc.CreateElement("login"); 
            login.InnerText = IFLogin.text; 

            XmlElement password = xmlDoc.CreateElement("password");
            password.InnerText = IFPassword.text; 

            XmlElement points = xmlDoc.CreateElement("points"); 
            points.InnerText = IFPoints.text; 

            elmNew.AppendChild(login); 
            elmNew.AppendChild(password); 
            elmNew.AppendChild(points); 

            elmRoot.AppendChild(elmNew); 

            xmlDoc.Save(filepath); 
        }
    }
}
